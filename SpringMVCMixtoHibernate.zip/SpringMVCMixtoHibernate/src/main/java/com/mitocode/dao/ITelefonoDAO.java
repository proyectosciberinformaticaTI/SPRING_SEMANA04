package com.mitocode.dao;

import com.mitocode.model.Telefono;

public interface ITelefonoDAO {

	void registrar(Telefono telefono);
}
