package com.mitocode.service;

import com.mitocode.model.Telefono;

public interface ITelefonoService {

    void registrar(Telefono telefono);
    
}
